
import React, { useState } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { BookOpen, GraduationCap, Medal, Users, UserCircle } from "lucide-react";

export default function DialogueAcademyPrototype() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState("");

  const handleLogin = () => {
    if (username.trim() !== "") setIsLoggedIn(true);
  };

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Dialogue Academy</h1>
      <p className="text-gray-600">Platform Pengembangan Diri Digital oleh Dialogue Group</p>

      {!isLoggedIn ? (
        <Card className="max-w-md mt-4">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-2">Login ke Akun Anda</h2>
            <Input
              placeholder="Masukkan Nama Pengguna"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mb-4"
            />
            <Button className="w-full" onClick={handleLogin}>
              Login
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="flex items-center gap-4 p-4 bg-gray-100 rounded-xl">
            <UserCircle className="text-blue-600" size={40} />
            <div>
              <p className="text-lg font-semibold">Selamat datang, {username}!</p>
              <p className="text-sm text-gray-500">Akses pembelajaran tersedia di bawah ini</p>
            </div>
          </div>

          <Tabs defaultValue="courses" className="w-full">
            <TabsList className="grid grid-cols-4 gap-2">
              <TabsTrigger value="courses">Kursus</TabsTrigger>
              <TabsTrigger value="bootcamp">Bootcamp</TabsTrigger>
              <TabsTrigger value="certification">Sertifikasi</TabsTrigger>
              <TabsTrigger value="ebook">E-Book</TabsTrigger>
            </TabsList>

            <TabsContent value="courses">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                {["Leadership", "Public Speaking", "Digital Marketing"].map((title) => (
                  <Card key={title} className="rounded-2xl shadow-md">
                    <CardContent className="p-4">
                      <BookOpen className="text-blue-600 mb-2" />
                      <h2 className="font-semibold text-lg">{title}</h2>
                      <p className="text-sm text-gray-500">Kursus online untuk meningkatkan {title.toLowerCase()} Anda.</p>
                      <Button className="mt-4 w-full">Lihat Kursus</Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="bootcamp">
              <Card className="mt-4 rounded-2xl shadow-md">
                <CardContent className="p-4">
                  <GraduationCap className="text-green-600 mb-2" />
                  <h2 className="font-semibold text-lg">Bootcamp Digital Branding</h2>
                  <p className="text-sm text-gray-500">Pelatihan intensif 1 minggu secara hybrid untuk menguasai branding digital.</p>
                  <Button className="mt-4">Daftar Sekarang</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="certification">
              <Card className="mt-4 rounded-2xl shadow-md">
                <CardContent className="p-4">
                  <Medal className="text-yellow-600 mb-2" />
                  <h2 className="font-semibold text-lg">Sertifikasi HR Profesional</h2>
                  <p className="text-sm text-gray-500">Dapatkan sertifikat resmi untuk meningkatkan portofolio profesional Anda.</p>
                  <Button className="mt-4">Ikuti Sertifikasi</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ebook">
              <Card className="mt-4 rounded-2xl shadow-md">
                <CardContent className="p-4">
                  <Users className="text-purple-600 mb-2" />
                  <h2 className="font-semibold text-lg">E-Book: Produktivitas Sejati</h2>
                  <p className="text-sm text-gray-500">Panduan praktis dalam meningkatkan produktivitas kerja dan manajemen waktu.</p>
                  <Button className="mt-4">Unduh Sekarang</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}
