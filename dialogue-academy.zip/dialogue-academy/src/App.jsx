
import DialogueAcademyPrototype from "./DialogueAcademyPrototype";

function App() {
  return <DialogueAcademyPrototype />;
}

export default App;
