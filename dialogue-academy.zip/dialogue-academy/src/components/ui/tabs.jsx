
import React, { useState } from "react";

export function Tabs({ defaultValue, children, className = "" }) {
  const [value, setValue] = useState(defaultValue);
  const tabs = React.Children.map(children, (child) =>
    child.type.name === "TabsList" || child.props.value === value ? React.cloneElement(child, { value, setValue }) : null
  );
  return <div className={className}>{tabs}</div>;
}

export function TabsList({ children, value, setValue, className = "" }) {
  return (
    <div className={className}>
      {React.Children.map(children, (child) =>
        React.cloneElement(child, { isActive: child.props.value === value, setValue })
      )}
    </div>
  );
}

export function TabsTrigger({ children, value, setValue, isActive, className = "" }) {
  return (
    <button
      className={`py-2 px-3 rounded-lg font-medium ${isActive ? "bg-blue-100 text-blue-600" : "bg-white text-gray-600"} ${className}`}
      onClick={() => setValue(value)}
    >
      {children}
    </button>
  );
}

export function TabsContent({ children, value, setValue, className = "" }) {
  return <div className={className}>{children}</div>;
}
